package figurinhas2;

public class Membro {
	private String nome, telefone;
	Album album;
	Repetidas repetidas;
	
	public Membro() {
		nome = "";
		telefone = "";
		album = new Album();
		repetidas = new Repetidas();
	}
	
	public Membro(String nome, String telefone) {
		this.nome = nome;
		this.telefone = telefone;		
		album = new Album();
		repetidas = new Repetidas();
	}
	
	public void addFigurinha(int nro) {
		if (nro > 0 && nro <= 50) {
			if (album.addFigAlbum(nro) == false) {
				repetidas.addFigRepetidas(nro);
			}
		} else {
			System.out.println("Indice invalido");
		}
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTelefone() {
		return telefone;
	}
	public Album getAlbum() {
		return album;
	}
	public Repetidas getRepetidas() {
		return repetidas;
	}
	
	public void mostraDados() {
		System.out.println("Nome: " + this.nome);
		System.out.println("Telefone: " + this.telefone);
		System.out.print("Album: ");
		for (int i = 0; i < 50; i++) {
			if (album.getQtdeFigurinhaAlbum(i) > 0) System.out.print(album.getFigurinhaAlbum(i) + " - ");
		}
		System.out.println();
		System.out.print("Repetidas: ");
		for (int i = 0; i < 50; i++) {
			for (int j = 0; j < repetidas.getQtdeFigurinha(i); j++) {
				System.out.print(repetidas.getFigurinhaRepetida(i) + " - ");
			}
		}
		System.out.println("\n");
	}
}
