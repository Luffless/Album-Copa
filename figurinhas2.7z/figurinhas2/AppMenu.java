package figurinhas2;

import java.util.ArrayList;
import java.util.Random;

public class AppMenu {
	public static void main(String[] args) {
		int choice;
		boolean sair = true;

		Random geraFig = new Random();
		ArrayList<Membro> membros = new ArrayList<Membro>();

		membros.add(new Membro("Jessica Jones", "99742477"));
		membros.add(new Membro("Usain Bolt", "99742477"));
		membros.add(new Membro("Dilma Rousseff", "99742477"));
		membros.add(new Membro("Thannos Roxo", "99742477"));
		membros.add(new Membro("Katy perry", "99742477"));

		Uteis.ordenaPorNome(membros);
		
		for (int i = 0; i < membros.size(); i++) {
			for (int j = 1; j <= 26; j++) {
				int nroFig = geraFig.nextInt(50);
				if (nroFig == 0)
					nroFig++;
				membros.get(i).addFigurinha(nroFig);
			}
		}

		do {
			int indice, qtde;
			String nome, telefone;
			Uteis.mostraMenu();
			choice = Uteis.lerInt("Escolha uma op��o: ");
			switch (choice) {
			case 0:
				sair = false;
				break;
			case 1:
				nome = Uteis.lerString("Informe o nome do novo componente");
				telefone = Uteis.lerString("Informe o telefone do respectivo componente");
				membros.add(new Membro(nome, telefone));
				if (membros.size() > 1)
					Uteis.ordenaPorNome(membros);
				break;
			case 2:
				if (membros.size() != 0) {
					do {
						nome = Uteis.lerString("Qual o nome do componente ao qual deseja adicionar figurinhas?");
						indice = Uteis.buscaMembro(nome, membros);
						if (indice != -1)
							break;
						System.out.println("Membro n�o encontrado, informe um membro corretamente");
					} while (true);
					do {
						qtde = Uteis.lerInt("Informe a quantidade de figurinhas que deseja inserir:");
						if (qtde >= 0)
							break;
						System.out.println("Informe uma quantidade maior que zero.");
						break;
					} while (true);

					for (int i = 0; i < qtde; i++) {
						int figurinha = Uteis.lerInt("Informe o n�mero da figurinha");
						membros.get(indice).addFigurinha(figurinha - 1);
					}
				} else {
					System.out.println("N�o possui membros ainda.");
				}
				break;
			case 3:
				do {
					nome = Uteis.lerString("Qual o nome do componente ao qual deseja saber as informa��es?");
					indice = Uteis.buscaMembro(nome, membros);
					if (indice != -1)
						break;
					System.out.println("Membro n�o encontrado, informe um membro corretamente");
				} while (true);
				membros.get(indice).mostraDados();
			case 4:
				for (int i = 0; i < membros.size(); i++) {
					membros.get(i).mostraDados();
				}
				break;
			case 5:
				Troca.trocaFigurinhas(membros);
				break;
			default:
				System.out.println("Invalido!");
				break;
			}
		} while (sair);

		for (int i = 0; i < 50; i++) {
			System.out.println();
		}
		System.out.println("APLICA��O FINALIZADA.");
	}
}
