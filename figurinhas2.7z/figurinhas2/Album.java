package figurinhas2;

import java.util.ArrayList;

public class Album {
	private ArrayList<Figurinha> figurinhas = new ArrayList<Figurinha>();

	public Album() {
		for (int i = 0; i < 50; i++) {
			figurinhas.add(new Figurinha(i+1));
		}
	}

	public boolean addFigAlbum(int nro) {
		if (figurinhas.get(nro).getQtdeFig() == 0) {
			figurinhas.get(nro).setQtdeFig(1);
			return true;				
		}
		return false;
	}

	public int getFigurinhaAlbum(int nro) {
		return figurinhas.get(nro).getNroFig();
	}
	
	public int getQtdeFigurinhaAlbum(int nro) {
		return figurinhas.get(nro).getQtdeFig();
	}

}
