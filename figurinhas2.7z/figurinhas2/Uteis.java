package figurinhas2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Uteis {

	private static BufferedReader ler = new BufferedReader(new InputStreamReader(System.in));

	public static int lerInt(String msg) {
		int int1 = 0;
		System.out.println(msg);
		do {
			try {
				int1 = Integer.parseInt(ler.readLine());
				return int1;
			} catch (IOException e) {
				System.out.println("Erro de leitura: ");
			} catch (NumberFormatException e) {
				System.out.println("Erro de leitura: ");
			}
		} while (true);
	}

	public static String lerString(String msg) {
		String str = "";
		System.out.println(msg);
		do {
			try {
				str = ler.readLine();
				return str;
			} catch (IOException e) {
				System.out.println("Erro de leitura: ");
			}
		} while (true);
	}

	public static void ordenaPorNome(ArrayList<Membro> membros) {
		Collections.sort(membros, new Comparator<Membro>() {
			@Override
			public int compare(Membro o1, Membro o2) {
				return o1.getNome().compareTo(o2.getNome());
			}
		});
	}

	public static int buscaMembro(String nome, ArrayList<Membro> membro) {
		for (int i = 0; i < membro.size(); i++) {
			if (membro.get(i).getNome().equals(nome))
				return i;
		}
		return -1;
	}

	public static void mostraMenu() {
		System.out.println("1 - Adicionar Membro");
		System.out.println("2 - Inser��o de figurinha:");
		System.out.println("3 - Dados de um componente");
		System.out.println("4 - Dados de todos os componentes");
		System.out.println("5 - Troca de figurinhas");
		System.out.println("0 - exit");
	}
}
