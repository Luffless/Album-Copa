package figurinhas2;

import java.util.ArrayList;

public class Troca {

	public static void trocaFigurinhas(ArrayList<Membro> membro) {
		Album aAtual, aProx;
		Repetidas rAtual, rProx;
		for (int i = 0; i < membro.size() - 1; i++) {
			aAtual = membro.get(i).getAlbum();
			rAtual = membro.get(i).getRepetidas();
			for (int j = i + 1; j < membro.size(); j++) {
				aProx = membro.get(j).getAlbum();
				rProx = membro.get(j).getRepetidas();
				tentaTrocar(aAtual, aProx, rAtual, rProx);
			}
		}
	}

	private static void tentaTrocar(Album aAtual, Album aProx, Repetidas rAtual, Repetidas rProx) {
		for (int i = 0; i < 50; i++) {
			int j = 0;
			boolean achou = false;
			if (rAtual.getQtdeFigurinha(i) > 0 && aProx.getQtdeFigurinhaAlbum(i) == 0) {
				do {
					if (rProx.getQtdeFigurinha(j) > 0 && aAtual.getQtdeFigurinhaAlbum(j) == 0) {
						achou = true;
						break;
					}
					j++;
				} while (j < 50);
				if (achou) {
					rAtual.removeFigurinha(i);
					aProx.addFigAlbum(i);
					rProx.removeFigurinha(j);
					aAtual.addFigAlbum(j);
					System.out.println(aAtual.getFigurinhaAlbum(j) + " - " + aProx.getFigurinhaAlbum(i));
				}
			}
		}
	}
}
