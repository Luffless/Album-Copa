package figurinhas2;

import java.util.ArrayList;

public class Repetidas {
	private ArrayList<Figurinha> repetidas = new ArrayList<Figurinha>();

	public Repetidas() {
		for (int i = 0; i < 50; i++) {
			repetidas.add(new Figurinha(i + 1));
		}
	}

	public void removeFigurinha(int nro) {
		repetidas.get(nro).retiraFigurinha();
	}

	public boolean addFigRepetidas(int nro) {
		if (nro > 0 && nro <= 50) {
			repetidas.get(nro).setQtdeFig(repetidas.get(nro).getQtdeFig() + 1);
			return true;
		}
		return false;
	}

	public int getFigurinhaRepetida(int nro) {
		return repetidas.get(nro).getNroFig();
	}

	public int getQtdeFigurinha(int nro) {
		return repetidas.get(nro).getQtdeFig();
	}
}
