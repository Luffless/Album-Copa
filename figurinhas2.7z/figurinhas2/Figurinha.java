package figurinhas2;

public class Figurinha {
	private int nroFig;
	private int qtdeFig;

	public Figurinha(int nro) {
		this.nroFig = nro;
		this.qtdeFig = 0;
	}

	public int getNroFig() {
		return nroFig;
	}

	public int getQtdeFig() {
		return qtdeFig;
	}

	public void retiraFigurinha() {
		this.qtdeFig--;
	}

	public void setQtdeFig(int qtdeFig) {
		this.qtdeFig = qtdeFig;
	}
}
